import pygame
import sys

pygame.init()

# 设置屏幕大小
screen = pygame.display.set_mode((1200, 800))
pygame.display.set_caption("Narrow Two")
#pygame.display.set_icon(r"")  # 设置图标

# 加载图片并设置颜色键
bow_image = pygame.image.load(r"C:\Users\student\Desktop\Narrow_Two\bow.png").convert()
bow_image.set_colorkey((255, 255, 255))


# 设置字体
font = pygame.font.Font(r"C:\Users\student\Desktop\Narrow_Two\DoreliaExtruderightDemo-MArxe.otf", 150)
text = font.render("NarrowTwo", True, (255, 255, 255))  # 渲染文字，颜色为白色
text_rect = text.get_rect(center=(600,275))  # 文字居中

font2 = pygame.font.Font(r"C:\Users\student\Desktop\Narrow_Two\DoreliaExtruderightDemo-MArxe.otf", 80)
text2 = font2.render("Click to start", True, (255, 255, 255))  # 渲染文字，颜色为白色
text_rect2 = text.get_rect(center=(775, 500))  # 文字居中

running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 绘制屏幕
    #screen.fill(0,0,0)  # 用黑色填充屏幕
    screen.blit(text, text_rect)  # 在屏幕的居中位置绘制文字
    screen.blit(text2, text_rect2)

    # 更新屏幕显示
    pygame.display.flip()

# 退出程序
pygame.quit()
sys.exit()
